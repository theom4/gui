import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';

export interface UserWithProfile extends User {
  role?: 'admin' | 'user';
  full_name?: string;
}

/**
 * Fetches the public profile of a user.
 * @param userId The ID of the user to fetch the profile for.
 * @returns The user's profile data or null if not found.
 */
export const getProfile = async (userId: string) => {
  // Add a timeout to avoid long UI blocking when backend is slow
  const withTimeout = async <T,>(p: Promise<T>, ms = 5000): Promise<T> => {
    return new Promise<T>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('Profile request timed out')), ms);
      p.then((v) => {
        clearTimeout(t);
        resolve(v);
      }).catch((e) => {
        clearTimeout(t);
        reject(e);
      });
    });
  };

  try {
    const { data, error } = await withTimeout(
      supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single()
    );

    if (error) {
      // PGRST116 = no rows found (not an error, just no profile yet)
      if (error.code === 'PGRST116') {
        return null;
      }
      throw error;
    }

    return data as Record<string, any> | null;
  } catch (e) {
    console.warn('Failed to fetch profile:', e);
    return null;
  }
};

/**
 * Fetches a list of all users and their profiles.
 * This is an admin-only function.
 * @returns A list of users with their profile information.
 */
export const getUsers = async (): Promise<UserWithProfile[]> => {
  try {
    const { data, error } = await supabase.functions.invoke('get-users');
    if (error) throw error;
    return data.users;
  } catch (err: any) {
    const msg = normalizeFunctionsError(err, 'fetching users');
    console.error('Error fetching users:', err);
    throw new Error(msg);
  }
};

/**
 * Creates a new user and their profile.
 * This is an admin-only function.
 * @param userData The data for the new user.
 * @returns The newly created user object.
 */
export const createUser = async (userData: Record<string, any>) => {
  try {
    const { data, error } = await supabase.functions.invoke('create-user', {
      body: userData,
    });
    if (error) throw error;
    return data;
  } catch (err: any) {
    const msg = normalizeFunctionsError(err, 'creating user');
    console.error('Error creating user:', err);
    throw new Error(msg);
  }
};

function normalizeFunctionsError(err: any, action: string) {
  const raw = typeof err?.message === 'string' ? err.message : String(err);
  if (/Failed to fetch|send to edge function|NetworkError/i.test(raw)) {
    return `Network error ${action}. Verifică Functions URL și CORS. În dev setează VITE_SUPABASE_FUNCTIONS_URL sau folosește local ${'http://localhost:54321/functions/v1'}.`;
  }
  if (/401|Unauthorized/i.test(raw)) return `Neautorizat ${action}. Re-autentifică-te.`;
  if (/403|Forbidden/i.test(raw)) return `Acces interzis ${action}. Necesită rol admin.`;
  return raw;
}
