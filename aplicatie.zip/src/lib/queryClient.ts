import { QueryClient } from '@tanstack/react-query';

/**
 * Optimized QueryClient Configuration
 *
 * Strategy:
 * - Smart caching with different stale times per data type
 * - Automatic garbage collection
 * - Page Visibility API integration
 * - Exponential backoff for retries
 */

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Global defaults - conservative approach
      staleTime: 30_000, // Data fresh for 30 seconds
      gcTime: 5 * 60_000, // Keep unused data in cache for 5 minutes (was cacheTime)

      // Retry strategy with exponential backoff
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30_000),

      // Page Visibility optimizations
      refetchOnWindowFocus: true, // Refetch when user returns to tab
      refetchOnMount: true, // Refetch on component mount if stale
      refetchOnReconnect: true, // Refetch when internet reconnects

      // Network mode
      networkMode: 'online',

      // Error handling
      throwOnError: false,
    },
    mutations: {
      retry: 1,
      networkMode: 'online',
    },
  },
});

/**
 * Query Keys - Centralized for consistency
 */
export const queryKeys = {
  // Call Metrics
  callMetrics: {
    all: ['call-metrics'] as const,
    latest: (userId: string) => ['call-metrics', 'latest', userId] as const,
    series: (userId: string, days: number) => ['call-metrics', 'series', userId, days] as const,
    unified: (userId: string) => ['call-metrics', 'unified', userId] as const,
  },

  // Call Recordings
  callRecordings: {
    all: ['call-recordings'] as const,
    list: (userId: string, limit: number, offset: number) =>
      ['call-recordings', 'list', userId, limit, offset] as const,
    latest: (userId: string) => ['call-recordings', 'latest', userId] as const,
  },

  // Admin
  admin: {
    users: ['admin', 'users'] as const,
  },

  // Profile
  profile: (userId: string) => ['profile', userId] as const,
} as const;

/**
 * Stale Time Configurations by Data Type
 * Based on update frequency and user expectations
 */
export const staleTimeConfig = {
  // TIER 1: Near Real-time (30 seconds)
  callMetricsSnapshot: 30_000, // Dashboard metrics updated frequently

  // TIER 2: Medium (5 minutes)
  callMetricsHistorical: 5 * 60_000, // Historical data doesn't change
  adminUsers: 60_000, // User registrations are rare

  // TIER 3: Aggressive Cache (30 minutes)
  userProfile: 30 * 60_000, // Profile rarely changes
  olderRecordings: 15 * 60_000, // Old recordings don't change
} as const;

/**
 * Refetch Interval Configurations
 * Automatic polling intervals when enabled
 */
export const refetchIntervalConfig = {
  callMetricsPolling: 30_000, // Poll every 30s for dashboard
  adminUsersPolling: 60_000, // Poll every 60s for admin dashboard
  disabled: false, // Use false to disable polling
} as const;
