import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/auth/AuthContext';
import {
  Users,
  TrendingUp,
  Activity,
  PhoneOutgoing,
  PhoneIncoming
} from "lucide-react"
import { MetricCard } from "@/components/MetricCard"
import { RevenueChart, VisitorChart, DeviceChart} from "@/components/DashboardChart"
import { useCallMetricsOptimized } from "@/hooks/useCallMetricsOptimized"
import { usePageVisibility } from "@/hooks/usePageVisibility"
import nanoassistLogo from '@/assets/nanoassist-logo-transparent.png';

// Charts now use data derived from Supabase

const mockPieData = [
  { name: 'Desktop', value: 400 },
  { name: 'Mobile', value: 300 },
  { name: 'Tablet', value: 200 },
  { name: 'Other', value: 100 },
];


const Index = () => {
  const auth = useAuth();
  const navigate = useNavigate();

  // 🚀 New optimized hook - replaces useCallMetrics + useCallMetricsSeries
  const { latest, previous, deltas, lineData, barData, loading, error, isRefetching } = useCallMetricsOptimized(14);

  // 🔥 Page Visibility API - automatically pauses/resumes fetching
  const { isVisible } = usePageVisibility();

  const percentChange = (current: number, previous: number) => {
    if (previous === 0) return current === 0 ? 0 : 100;
    return ((current - previous) / Math.abs(previous)) * 100;
  };

  const formatSeconds = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = Math.max(0, totalSeconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const avgSecLatest = latest ? Math.round(((latest.minute_consumate ?? 0) * 60) / Math.max(1, (latest.total_apeluri ?? 0))) : 0;
  const avgSecPrev = previous ? Math.round(((previous.minute_consumate ?? 0) * 60) / Math.max(1, (previous.total_apeluri ?? 0))) : 0;
  const avgDelta = percentChange(avgSecLatest, avgSecPrev);

  // No local auth listeners; rely on global App AuthProvider routing

  // Removed Sign Out button and handler

  // Index is only mounted for authenticated users by AppRoutes

  // Check if there's any data
  const hasData = latest && (
    latest.total_apeluri > 0 ||
    latest.apeluri_initiate > 0 ||
    latest.apeluri_primite > 0 ||
    latest.minute_consumate > 0
  );

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <img
            src={nanoassistLogo}
            alt="NanoAssist Logo"
            className="h-10 w-auto object-contain mix-blend-multiply"
            style={{ background: 'transparent' }}
          />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Statistici Apeluri Specialist Suplimente</h1>
            <p className="text-muted-foreground">
              Welcome back, {auth.profile?.full_name || 'User'}
            </p>
          </div>
        </div>
        {/* Sign Out button removed as requested */}
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center p-12">
          <div className="text-center space-y-4">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <p className="text-muted-foreground">Se încarcă datele...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <h3 className="text-lg font-semibold text-red-900 mb-2">Eroare la încărcarea datelor</h3>
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && !hasData && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-12 text-center">
          <Activity className="h-16 w-16 text-blue-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-blue-900 mb-2">Nu există date disponibile</h3>
          <p className="text-blue-700 mb-4">
            Încă nu există apeluri înregistrate pentru contul tău.
          </p>
          <p className="text-sm text-blue-600">
            Datele vor apărea automat după ce vei efectua primul apel.
          </p>
        </div>
      )}

      {/* Data Display - Only show when there's data */}
      {!loading && !error && hasData && (
        <>
          {/* Metrics Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <MetricCard
              title="Total Apeluri"
              value={(latest?.total_apeluri ?? 0).toLocaleString()}
              change={parseFloat((deltas.total_apeluri ?? 0).toFixed(2))}
              changeLabel="from last period"
              icon={Users}
              trend={(deltas.total_apeluri ?? 0) >= 0 ? 'up' : 'down'}
            />
            <MetricCard
              title="Apeluri Initiate"
              value={(latest?.apeluri_initiate ?? 0).toLocaleString()}
              change={parseFloat((deltas.apeluri_initiate ?? 0).toFixed(2))}
              changeLabel="from last period"
              icon={PhoneOutgoing}
              trend={(deltas.apeluri_initiate ?? 0) >= 0 ? 'up' : 'down'}
            />
            <MetricCard
              title="Apeluri Primite"
              value={(latest?.apeluri_primite ?? 0).toLocaleString()}
              change={parseFloat((deltas.apeluri_primite ?? 0).toFixed(2))}
              changeLabel="from last period"
              icon={PhoneIncoming}
              trend={(deltas.apeluri_primite ?? 0) >= 0 ? 'up' : 'down'}
            />
            <MetricCard
              title="Rata Conversie"
              value={`${(latest?.rata_conversie ?? 0).toFixed(2)}%`}
              change={parseFloat((deltas.rata_conversie ?? 0).toFixed(2))}
              changeLabel="from last period"
              icon={TrendingUp}
              trend={(deltas.rata_conversie ?? 0) >= 0 ? 'up' : 'down'}
            />
          </div>

          {/* Charts Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <RevenueChart data={lineData} loading={loading} error={error} />
            <VisitorChart data={barData} loading={loading} error={error} />
            <DeviceChart data={mockPieData} loading={loading} error={error} />
          </div>
        </>
      )}
    </div>
  );
};

export default Index;
