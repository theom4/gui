import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, CheckCircle2, Loader2, RefreshCw, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import QRCode from "react-qr-code";

interface SessionResponse {
  success: boolean;
  status?: string;
  sessionId?: number;
  sessionName?: string;
  phoneNumber?: string;
  createdAt?: string;
  qrCode?: string;
  message?: string;
  error?: string;
}

const WhatsApp = () => {
  const [loading, setLoading] = useState(false);
  const [sessionData, setSessionData] = useState<SessionResponse | null>(null);
  const [polling, setPolling] = useState(false);
  const { toast } = useToast();

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    return date.toLocaleDateString('ro-RO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const checkSession = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke<SessionResponse>(
        'whatsapp-session-manager',
        {
          method: 'POST',
          body: { action: 'check' }
        }
      );

      if (error) {
        throw error;
      }

      setSessionData(data);

      if (data?.status === 'NEED_SCAN') {
        // Start polling to check if user scanned the QR code
        setPolling(true);
      } else if (data?.status === 'CONNECTED') {
        setPolling(false);
        toast({
          title: "WhatsApp Connected",
          description: "Your WhatsApp session is active!",
        });
      }

    } catch (error) {
      console.error('Error checking session:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to check WhatsApp session",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const disconnectSession = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke<SessionResponse>(
        'whatsapp-session-manager',
        {
          method: 'POST',
          body: { action: 'disconnect' }
        }
      );

      if (error) {
        throw error;
      }

      setSessionData(data);
      setPolling(false);

      toast({
        title: "WhatsApp Disconnected",
        description: "Your WhatsApp session has been disconnected successfully",
      });

      // Refresh session status after disconnect
      setTimeout(() => checkSession(), 1000);

    } catch (error) {
      console.error('Error disconnecting session:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to disconnect WhatsApp session",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Auto-check session on mount
  useEffect(() => {
    checkSession();
  }, []);

  // Polling effect - check every 30 seconds if waiting for QR scan
  useEffect(() => {
    if (!polling) return;

    const interval = setInterval(() => {
      checkSession();
    }, 30000);

    return () => clearInterval(interval);
  }, [polling]);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">WhatsApp</h1>
        <p className="text-muted-foreground">
          Gestionează sesiunea ta de WhatsApp
        </p>
      </div>

      <Card className="p-8">
        <div className="flex flex-col items-center justify-center space-y-6 text-center">

          {/* Loading State */}
          {loading && !sessionData && (
            <>
              <div className="rounded-full bg-primary/10 p-6">
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
              </div>
              <div className="space-y-2 max-w-md">
                <h2 className="text-2xl font-semibold">Verificare sesiune...</h2>
                <p className="text-muted-foreground">
                  Se verifică statusul sesiunii WhatsApp
                </p>
              </div>
            </>
          )}

          {/* Connected State */}
          {!loading && sessionData?.status === 'CONNECTED' && (
            <>
              <div className="rounded-full bg-green-100 p-6">
                <CheckCircle2 className="h-12 w-12 text-green-600" />
              </div>
              <div className="space-y-3 max-w-md">
                <h2 className="text-2xl font-semibold text-green-600">Conectat!</h2>
                <p className="text-muted-foreground">
                  Sesiunea ta WhatsApp este activă
                </p>

                {/* Session Details */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-left space-y-2">
                  {sessionData.sessionName && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-green-900">Nume:</span>
                      <span className="text-sm text-green-700">{sessionData.sessionName}</span>
                    </div>
                  )}
                  {sessionData.sessionId && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-green-900">ID:</span>
                      <span className="text-sm text-green-700 font-mono">{sessionData.sessionId}</span>
                    </div>
                  )}
                  {sessionData.phoneNumber && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-green-900">Număr:</span>
                      <span className="text-sm text-green-700 font-mono">{sessionData.phoneNumber}</span>
                    </div>
                  )}
                  {sessionData.createdAt && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-green-900">Creată:</span>
                      <span className="text-sm text-green-700">{formatDate(sessionData.createdAt)}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={checkSession} variant="outline">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Verifică din nou
                </Button>
                <Button onClick={disconnectSession} variant="destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Deconectează
                </Button>
              </div>
            </>
          )}

          {/* Need Scan State - Show QR Code */}
          {!loading && sessionData?.status === 'NEED_SCAN' && sessionData.qrCode && (
            <>
              <div className="space-y-4">
                <div className="rounded-full bg-yellow-100 p-6 mx-auto w-fit">
                  <MessageCircle className="h-12 w-12 text-yellow-600" />
                </div>

                <div className="space-y-3 max-w-md">
                  <h2 className="text-2xl font-semibold text-yellow-600">Scanează QR Code</h2>
                  <p className="text-muted-foreground">
                    Deschide WhatsApp pe telefon și scanează codul de mai jos
                  </p>

                  {/* Session Details */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-left space-y-2">
                    {sessionData.sessionName && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-yellow-900">Nume:</span>
                        <span className="text-sm text-yellow-700">{sessionData.sessionName}</span>
                      </div>
                    )}
                    {sessionData.sessionId && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-yellow-900">ID:</span>
                        <span className="text-sm text-yellow-700 font-mono">{sessionData.sessionId}</span>
                      </div>
                    )}
                    {sessionData.phoneNumber && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-yellow-900">Număr:</span>
                        <span className="text-sm text-yellow-700 font-mono">{sessionData.phoneNumber}</span>
                      </div>
                    )}
                    {sessionData.createdAt && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-yellow-900">Creată:</span>
                        <span className="text-sm text-yellow-700">{formatDate(sessionData.createdAt)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* QR Code Display */}
                <div className="bg-white p-6 rounded-lg shadow-md mx-auto">
                  <QRCode
                    value={sessionData.qrCode}
                    size={256}
                    level="H"
                  />
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Așteptare scanare... (verificare automată)</span>
                </div>

                <Button onClick={checkSession} variant="outline" size="sm">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Verifică manual
                </Button>
              </div>
            </>
          )}

          {/* Error or No Data State */}
          {!loading && !sessionData && (
            <>
              <div className="rounded-full bg-primary/10 p-6">
                <MessageCircle className="h-12 w-12 text-primary" />
              </div>
              <div className="space-y-2 max-w-md">
                <h2 className="text-2xl font-semibold">Sesiune WhatsApp</h2>
                <p className="text-muted-foreground">
                  Verifică statusul sesiunii tale WhatsApp
                </p>
              </div>
              <Button onClick={checkSession}>
                Verifică sesiunea
              </Button>
            </>
          )}

          {/* Error Message */}
          {sessionData?.error && (
            <div className="text-red-500 text-sm mt-2">
              {sessionData.error}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default WhatsApp;
