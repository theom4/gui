import { useEffect, useState } from "react";
import { Activity, Users, UserCheck } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { supabase } from "@/integrations/supabase/client";
import { Bar, BarChart, CartesianGrid, XAxis } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

// Define the structure of a user object
interface User {
  id: string;
  email?: string;
  full_name?: string;
  created_at?: string;
  last_sign_in_at?: string;
}

// Define the structure for chart data
interface ChartData {
  date: string;
  users: number;
}

// Main Dashboard Component
export default function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase.functions.invoke("get-users");
        if (error) throw new Error(error.message);
        if (data?.users) {
          setUsers(data.users);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Process data for metrics and charts
  const totalUsers = users.length;
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const newUsersLast30Days = users.filter(u => u.created_at && new Date(u.created_at) > thirtyDaysAgo).length;
  const activeUsersLast30Days = users.filter(u => u.last_sign_in_at && new Date(u.last_sign_in_at) > thirtyDaysAgo).length;
  const recentUsers = users.sort((a, b) => new Date(b.created_at!).getTime() - new Date(a.created_at!).getTime()).slice(0, 5);

  // Generate chart data for the last 7 days
  const chartData: ChartData[] = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return { date: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), users: 0 };
  }).reverse();

  users.forEach(user => {
    if (user.created_at) {
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const userDate = new Date(user.created_at);
      if (userDate > sevenDaysAgo) {
        const formattedDate = userDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const dayData = chartData.find(d => d.date === formattedDate);
        if (dayData) {
          dayData.users++;
        }
      }
    }
  });

  if (loading) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-8 text-center">
          <h3 className="text-lg font-semibold text-red-900 mb-2">Eroare la încărcarea dashboard-ului</h3>
          <p className="text-red-700">{error}</p>
          <p className="text-sm text-red-600 mt-2">Te rugăm să verifici conexiunea și să încerci din nou.</p>
        </div>
      </main>
    );
  }

  // Check if there are no users
  const hasUsers = users.length > 0;

  return (
    <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      {!hasUsers ? (
        // Empty state when no users exist
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-12 text-center">
          <Users className="h-16 w-16 text-blue-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-blue-900 mb-2">Nu există utilizatori înregistrați</h3>
          <p className="text-blue-700 mb-4">
            Nu există încă utilizatori în sistem.
          </p>
          <p className="text-sm text-blue-600">
            Utilizatorii vor apărea aici după ce se vor înregistra în aplicație.
          </p>
        </div>
      ) : (
        // Normal dashboard view when users exist
        <>
          <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalUsers}</div>
                <p className="text-xs text-muted-foreground">All registered users</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">New Users</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+{newUsersLast30Days}</div>
                <p className="text-xs text-muted-foreground">In the last 30 days</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                <UserCheck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeUsersLast30Days}</div>
                <p className="text-xs text-muted-foreground">Signed in last 30 days</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-4 md:gap-8 lg:grid-cols-2 xl:grid-cols-3">
            <Card className="xl:col-span-2">
              <CardHeader>
                <CardTitle>New User Growth</CardTitle>
                <CardDescription>New users registered in the last 7 days.</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <ChartContainer config={{}} className="aspect-auto h-[250px] w-full">
                  <BarChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickLine={false} tickMargin={10} axisLine={false} />
                    <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dot" />} />
                    <Bar dataKey="users" fill="hsl(var(--primary))" radius={8} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Recent Registrations</CardTitle>
                <CardDescription>The last 5 users who registered.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-6">
                {recentUsers.length > 0 ? (
                  recentUsers.map(user => (
                    <div key={user.id} className="flex items-center gap-4">
                      <Avatar className="hidden h-9 w-9 sm:flex">
                        <AvatarFallback>{user.full_name ? user.full_name.charAt(0) : user.email?.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="grid gap-1">
                        <p className="text-sm font-medium leading-none">{user.full_name || 'N/A'}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <div className="ml-auto text-sm text-muted-foreground">
                        {new Date(user.created_at!).toLocaleDateString()}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-muted-foreground text-center py-4">
                    Nu există înregistrări recente
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </main>
  );
}

// Skeleton component for loading state
const DashboardSkeleton = () => (
  <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
    <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-3">
      <Card><CardHeader><Skeleton className="h-5 w-3/4" /></CardHeader><CardContent><Skeleton className="h-8 w-1/2" /></CardContent></Card>
      <Card><CardHeader><Skeleton className="h-5 w-3/4" /></CardHeader><CardContent><Skeleton className="h-8 w-1/2" /></CardContent></Card>
      <Card><CardHeader><Skeleton className="h-5 w-3/4" /></CardHeader><CardContent><Skeleton className="h-8 w-1/2" /></CardContent></Card>
    </div>
    <div className="grid gap-4 md:gap-8 lg:grid-cols-2 xl:grid-cols-3">
      <Card className="xl:col-span-2">
        <CardHeader>
          <Skeleton className="h-5 w-1/4" />
          <Skeleton className="h-4 w-2/4" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[250px] w-full" />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-1/4" />
          <Skeleton className="h-4 w-2/4" />
        </CardHeader>
        <CardContent className="grid gap-6">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-4">
              <Skeleton className="h-9 w-9 rounded-full" />
              <div className="grid gap-1 w-full">
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  </main>
);
