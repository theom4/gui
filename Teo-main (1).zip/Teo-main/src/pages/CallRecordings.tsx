import { useMemo } from "react";
import { Phone, Play, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/auth/AuthContext";
import { MetricCard } from "@/components/MetricCard";
import { useCallMetricsOptimized } from "@/hooks/useCallMetricsOptimized";
import { useCallRecordingsOptimized } from "@/hooks/useCallRecordingsOptimized";
import { usePageVisibility } from "@/hooks/usePageVisibility";

type CallRecording = {
  id: number;
  user_id: string;
  created_at: string;
  duration_seconds: number | null;
  recording_url: string;
};

function formatDuration(seconds: number | null): string {
  if (!seconds || seconds < 0) return "-";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString("ro-RO", {
      year: "numeric",
      month: "long",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

const CallRecordings = () => {
  const { profile } = useAuth();

  // 🚀 Optimized hooks
  const { latest, previous, deltas } = useCallMetricsOptimized(14);
  const { recordings, loading, error, isRefetching } = useCallRecordingsOptimized(20);
  const { isVisible } = usePageVisibility();

  const formatSeconds = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = Math.max(0, totalSeconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const percentChange = (current: number, previous: number) => {
    if (previous === 0) return current === 0 ? 0 : 100;
    return ((current - previous) / Math.abs(previous)) * 100;
  };

  const avgSecLatest = latest ? Math.round(((latest.minute_consumate ?? 0) * 60) / Math.max(1, (latest.total_apeluri ?? 0))) : 0;
  const avgSecPrev = previous ? Math.round(((previous.minute_consumate ?? 0) * 60) / Math.max(1, (previous.total_apeluri ?? 0))) : 0;
  const avgDelta = percentChange(avgSecLatest, avgSecPrev);

  const content = useMemo(() => {
    if (loading) return <div className="p-4 text-sm text-muted-foreground">Se încarcă înregistrările...</div>;
    if (error) return <div className="p-4 text-sm text-red-600">Eroare: {error}</div>;
    if (!recordings.length)
      return <div className="p-4 text-sm text-muted-foreground">Nu există înregistrări pentru acest cont.</div>;
    return (
      <div className="space-y-4">
        {recordings.map((rec) => (
          <div
            key={rec.id}
            onClick={() => window.open(rec.recording_url, "_blank")}
            className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Play className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">Apel #{rec.id}</p>
                <p className="text-sm text-muted-foreground">{formatDate(rec.created_at)}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium">{formatDuration(rec.duration_seconds)}</p>
              <p className="text-xs text-muted-foreground">Durată</p>
            </div>
          </div>
        ))}
      </div>
    );
  }, [recordings, loading, error]);

  // Check if there's any call data
  const hasCallData = latest && (
    latest.total_apeluri > 0 ||
    latest.minute_consumate > 0
  );

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Phone className="h-8 w-8" />
          Înregistrări Apeluri
        </h1>
        <p className="text-muted-foreground mt-2">Ascultă și gestionează înregistrările apelurilor</p>
      </div>

      {/* Loading State for Metrics */}
      {loading && (
        <div className="flex items-center justify-center p-12">
          <div className="text-center space-y-4">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <p className="text-muted-foreground">Se încarcă datele...</p>
          </div>
        </div>
      )}

      {/* Show metric card only if there's data */}
      {!loading && hasCallData && (
        <MetricCard
          title="Durata Medie Apel"
          value={formatSeconds(avgSecLatest)}
          change={Number.isFinite(avgDelta) ? Math.round((avgDelta + Number.EPSILON) * 10) / 10 : 0}
          changeLabel="from last period"
          icon={Activity}
          trend={avgDelta >= 0 ? 'up' : 'down'}
        />
      )}

      {/* Recordings Card */}
      {!loading && (
        <Card>
          <CardHeader>
            <CardTitle>Înregistrări Recente (Ultimi 20)</CardTitle>
          </CardHeader>
          <CardContent>{content}</CardContent>
        </Card>
      )}
    </div>
  );
};

export default CallRecordings;
