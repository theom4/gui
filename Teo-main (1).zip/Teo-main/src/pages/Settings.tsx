const Settings = () => {
  return (
    <div className="flex-1 p-6 flex items-center justify-center">
      <div className="max-w-2xl text-center space-y-4">
        <h1 className="text-2xl font-semibold tracking-tight">Setări și Personalizare</h1>
        <p className="text-muted-foreground">
          Pentru configurări avansate și personalizarea pachetului (fluxuri de lucru,
          roluri și permisiuni, integrare cu CRM/telefonie, limite de utilizare, SLA-uri),
          te rugăm să contactezi echipa Nano Assistant.
        </p>
        <p className="text-muted-foreground">
          Putem ajuta cu: audit inițial, plan de implementare, migrare de date,
          training pentru echipă și asistență prioritară.
        </p>
        <p className="text-muted-foreground">
          Ne poți contacta din centrul de suport al aplicației sau prin reprezentantul tău
          comercial. Echipa noastră răspunde, de regulă, în maximum o zi lucrătoare.
        </p>
      </div>
    </div>
  );
};

export default Settings;
